import { filters, renderWardrobe, wardrobeEvents, search } from "./utils/wardrobeUtils.js";
import { clothingItems } from "./utils/storageUtils.js";

const wardrobeGrid = document.querySelector('.wardrobe-grid');
const filterButtons = document.querySelectorAll('#filter-buttons button');
const searchInput = document.querySelector('#search');
const searchButton = document.querySelector('#search-button')

renderWardrobe(wardrobeGrid);

const reapplyCurrentFilter = filters(filterButtons, wardrobeGrid);

wardrobeEvents(wardrobeGrid, reapplyCurrentFilter);

search(searchInput, clothingItems, (filteredItems) => {
    renderWardrobe(wardrobeGrid, filteredItems);
});
